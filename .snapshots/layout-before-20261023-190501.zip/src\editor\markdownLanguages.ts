import { LanguageDescription } from "@codemirror/language";

// 语言包按需加载，避免把全部语法包塞进首屏主 chunk。
export const markdownCodeLanguages = [
  LanguageDescription.of({
    name: "Rust",
    alias: ["rust", "rs"],
    load: () =>
      import("@codemirror/lang-rust").then((module) => module.rust()),
  }),
  LanguageDescription.of({
    name: "JavaScript",
    alias: ["javascript", "js", "jsx"],
    load: () =>
      import("@codemirror/lang-javascript").then((module) =>
        module.javascript({ jsx: true }),
      ),
  }),
  LanguageDescription.of({
    name: "TypeScript",
    alias: ["typescript", "ts", "tsx"],
    load: () =>
      import("@codemirror/lang-javascript").then((module) =>
        module.javascript({ jsx: true, typescript: true }),
      ),
  }),
  LanguageDescription.of({
    name: "Python",
    alias: ["python", "py"],
    load: () =>
      import("@codemirror/lang-python").then((module) => module.python()),
  }),
  LanguageDescription.of({
    name: "JSON",
    alias: ["json"],
    load: () =>
      import("@codemirror/lang-json").then((module) => module.json()),
  }),
  LanguageDescription.of({
    name: "HTML",
    alias: ["html"],
    load: () =>
      import("@codemirror/lang-html").then((module) => module.html()),
  }),
  LanguageDescription.of({
    name: "CSS",
    alias: ["css"],
    load: () =>
      import("@codemirror/lang-css").then((module) => module.css()),
  }),
];
