import type { Command } from "@codemirror/view";

function wrapSelection(
  view: Parameters<Command>[0],
  marker: string,
  placeholder: string,
): boolean {
  const state = view.state;
  const selection = state.selection.main;
  const selected = state.doc.sliceString(selection.from, selection.to);
  const length = marker.length;

  if (selected.length >= length * 2) {
    if (selected.startsWith(marker) && selected.endsWith(marker)) {
      const inner = selected.slice(length, -length);
      view.dispatch({
        changes: { from: selection.from, to: selection.to, insert: inner },
        selection: {
          anchor: selection.from,
          head: selection.from + inner.length,
        },
      });
      return true;
    }
  }

  if (selection.empty) {
    const before = state.doc.sliceString(
      Math.max(0, selection.from - length),
      selection.from,
    );
    const after = state.doc.sliceString(
      selection.to,
      Math.min(state.doc.length, selection.to + length),
    );
    if (before === marker && after === marker) {
      view.dispatch({
        changes: [
          { from: selection.from - length, to: selection.from, insert: "" },
          { from: selection.to, to: selection.to + length, insert: "" },
        ],
        selection: { anchor: selection.from - length },
      });
      return true;
    }
  }

  const content = selected || placeholder;
  const insert = `${marker}${content}${marker}`;
  view.dispatch({
    changes: { from: selection.from, to: selection.to, insert },
    selection: {
      anchor: selection.from + length,
      head: selection.from + length + content.length,
    },
  });
  return true;
}

export const toggleBold: Command = (view) =>
  wrapSelection(view, "**", "加粗文字");

export const toggleItalic: Command = (view) =>
  wrapSelection(view, "*", "斜体文字");

export const insertLink: Command = (view) => {
  const selection = view.state.selection.main;
  const selected = view.state.doc.sliceString(selection.from, selection.to);
  const label = selected || "链接文字";
  const insert = `[${label}](url)`;
  const urlStart = selection.from + label.length + 3;
  view.dispatch({
    changes: { from: selection.from, to: selection.to, insert },
    selection: { anchor: urlStart, head: urlStart + 3 },
  });
  return true;
};

function setHeading(view: Parameters<Command>[0], level: number): boolean {
  const selection = view.state.selection.main;
  const line = view.state.doc.lineAt(selection.from);
  const match = line.text.match(/^(#{1,6})\s+/);
  const from = line.from;
  const to = line.from + (match?.[0].length ?? 0);
  const currentLevel = match?.[1].length ?? 0;
  const prefix = currentLevel === level ? "" : `${"#".repeat(level)} `;
  const delta = prefix.length - (to - from);
  view.dispatch({
    changes: { from, to, insert: prefix },
    selection: {
      anchor: Math.max(from, selection.anchor + delta),
      head: Math.max(from, selection.head + delta),
    },
  });
  return true;
}

export const clearHeading: Command = (view) => {
  const selection = view.state.selection.main;
  const line = view.state.doc.lineAt(selection.from);
  const match = line.text.match(/^(#{1,6})\s+/);
  if (!match) {
    return false;
  }
  const from = line.from;
  const remove = match[0].length;
  view.dispatch({
    changes: { from, to: from + remove, insert: "" },
    selection: {
      anchor: Math.max(from, selection.anchor - remove),
      head: Math.max(from, selection.head - remove),
    },
  });
  return true;
};

export const heading1: Command = (view) => setHeading(view, 1);
export const heading2: Command = (view) => setHeading(view, 2);
export const heading3: Command = (view) => setHeading(view, 3);
export const heading4: Command = (view) => setHeading(view, 4);
export const heading5: Command = (view) => setHeading(view, 5);
export const heading6: Command = (view) => setHeading(view, 6);
