import { useCallback, useEffect, useRef, useState } from "react";
import { invoke } from "@tauri-apps/api/core";
import { open } from "@tauri-apps/plugin-dialog";
import { getCurrentWindow } from "@tauri-apps/api/window";
import DockWorkspace, {
  DOCK_LAYOUT_KEY,
  type DockWorkspaceHandle,
} from "./components/DockWorkspace";
import SearchPalette from "./components/SearchPalette";
import type {
  MapView,
  NodeView,
  SearchHit,
  WorkspaceView,
} from "./types";

function findNode(node: NodeView, id: string): NodeView | null {
  if (node.id === id) {
    return node;
  }
  for (const child of node.children) {
    const found = findNode(child, id);
    if (found) {
      return found;
    }
  }
  return null;
}

function App() {
  const [workspace, setWorkspace] = useState<WorkspaceView | null>(null);
  const [activeMapId, setActiveMapId] = useState<string | null>(null);
  const [selected, setSelected] = useState<NodeView | null>(null);
  const [backend, setBackend] = useState("未连接");
  const [busy, setBusy] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dirtyPanels, setDirtyPanels] = useState<Record<string, boolean>>({});
  const [theme, setTheme] = useState<"dark" | "light">(() =>
    window.localStorage.getItem("tauri-notes.theme") === "light"
      ? "light"
      : "dark",
  );
  const [logs, setLogs] = useState<string[]>(["Tauri Notes 已启动"]);
  const dockRef = useRef<DockWorkspaceHandle>(null);
  const dirtyRef = useRef(0);
  const autoOpened = useRef(false);

  const appendLog = useCallback((line: string) => {
    setLogs((current) => [...current.slice(-99), line]);
  }, []);

  const activeMap: MapView | null =
    workspace?.maps.find((map) => map.id === activeMapId) ?? null;
  const dirtyCount = Object.values(dirtyPanels).filter(Boolean).length;
  dirtyRef.current = dirtyCount;

  const handlePanelDirty = useCallback((panelId: string, dirty: boolean) => {
    setDirtyPanels((current) => {
      if (Boolean(current[panelId]) === dirty) {
        return current;
      }
      const next = { ...current };
      if (dirty) {
        next[panelId] = true;
      } else {
        delete next[panelId];
      }
      return next;
    });
  }, []);

  function confirmDiscard(): boolean {
    if (dirtyCount === 0) {
      return true;
    }
    return window.confirm(
      `有 ${dirtyCount} 个面板还有未保存的修改，确定离开吗？`,
    );
  }

  useEffect(() => {
    getCurrentWindow()
      .setTitle(dirtyCount > 0 ? "• Tauri Notes" : "Tauri Notes")
      .catch(() => {});
  }, [dirtyCount]);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    window.localStorage.setItem("tauri-notes.theme", theme);
  }, [theme]);

  useEffect(() => {
    let unlisten: (() => void) | undefined;
    let disposed = false;

    getCurrentWindow()
      .onCloseRequested((event) => {
        // 没有脏面板时走原生关闭，避免任何权限/WebView2 事件卡住。
        if (dirtyRef.current === 0) {
          return;
        }
        event.preventDefault();
        if (!window.confirm("关闭会丢失未保存的修改，仍要关闭吗？")) {
          return;
        }
        void getCurrentWindow().destroy();
      })
      .then((fn) => {
        if (disposed) {
          fn();
        } else {
          unlisten = fn;
        }
      })
      .catch(() => {});

    return () => {
      disposed = true;
      unlisten?.();
    };
  }, []);

  useEffect(() => {
    function onKeyDown(event: KeyboardEvent) {
      if (
        (event.ctrlKey || event.metaKey) &&
        event.key.toLowerCase() === "p" &&
        workspace
      ) {
        event.preventDefault();
        setSearchOpen(true);
      }
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [workspace]);

  async function checkBackend() {
    setBusy(true);
    try {
      const greeting = await invoke<string>("greet", { name: "Notes" });
      setBackend(greeting);
    } catch (err) {
      setBackend(`后端未启动：${String(err)}`);
    } finally {
      setBusy(false);
    }
  }

  async function openWorkspacePath(picked: string) {
    if (!confirmDiscard()) {
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const view = await invoke<WorkspaceView>("open_workspace", { path: picked });
      const map = view.maps[0] ?? null;
      const root = map?.root ?? null;
      setWorkspace(view);
      setActiveMapId(map?.id ?? null);
      setSelected(root);
      setBackend(`已打开：${view.title}（${view.maps.length} 张导图）`);
      appendLog(`打开知识库：${view.title}`);
      if (map && root) {
        dockRef.current?.openDocument(map.id, root.id);
      }
    } catch (err) {
      setError(String(err));
    } finally {
      setBusy(false);
    }
  }

  async function openWorkspace() {
    if (!confirmDiscard()) {
      return;
    }
    setError(null);
    try {
      const picked = await open({
        directory: true,
        multiple: false,
        title: "打开 .notes 知识库",
      });
      if (!picked || Array.isArray(picked)) {
        return;
      }
      await openWorkspacePath(picked);
    } catch (err) {
      setError(String(err));
    }
  }

  async function openDemo() {
    if (!confirmDiscard()) {
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const path = await invoke<string>("demo_workspace");
      await openWorkspacePath(path);
    } catch (err) {
      setError(String(err));
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => {
    if (autoOpened.current) {
      return;
    }
    autoOpened.current = true;
    void openDemo();
    // 只在首次启动自动打开示例；后续切换由用户操作。
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function selectNode(node: NodeView) {
    if (node.id !== selected?.id && !confirmDiscard()) {
      return;
    }
    if (!activeMap) {
      return;
    }
    setSelected(node);
    appendLog(`打开节点：${node.title}`);
    dockRef.current?.openDocument(activeMap.id, node.id);
  }

  function switchMap(map: MapView) {
    if (!confirmDiscard()) {
      return;
    }
    setActiveMapId(map.id);
    setSelected(map.root);
    appendLog(`切换导图：${map.title}`);
    dockRef.current?.openDocument(map.id, map.root.id);
  }

  function openSearchHit(hit: SearchHit) {
    if (!workspace) {
      return;
    }
    if (!confirmDiscard()) {
      return;
    }
    const map = workspace.maps.find((item) => item.id === hit.mapId);
    const node = map ? findNode(map.root, hit.nodeId) : null;
    if (!map || !node) {
      setError("搜索结果对应的节点不存在");
      return;
    }
    setSearchOpen(false);
    setActiveMapId(map.id);
    setSelected(node);
    appendLog(`搜索打开：${node.title}`);
    dockRef.current?.openDocument(map.id, node.id);
  }

  function openInNewPanel() {
    if (!activeMap || !selected) {
      return;
    }
    appendLog(`新建文档面板：${selected.title}`);
    dockRef.current?.openDocument(activeMap.id, selected.id);
  }

  function openNewMap() {
    if (!activeMap) {
      return;
    }
    appendLog(`新建导图面板：${activeMap.title}`);
    dockRef.current?.openMap(activeMap.id, true);
  }

  return (
    <div className="app">
      <header className="toolbar">
        <div className="brand">
          <span className="brand-mark">N</span>
          <span>Notes</span>
        </div>
        <div className="toolbar-actions">
          <button type="button" onClick={openWorkspace} disabled={busy}>
            打开知识库
          </button>
          <button
            type="button"
            onClick={() => setSearchOpen(true)}
            disabled={busy || !workspace}
          >
            搜索
          </button>
          <button
            type="button"
            onClick={openInNewPanel}
            disabled={busy || !selected}
            title="把当前节点在独立的新文档面板打开"
          >
            新建文档
          </button>
          <button
            type="button"
            onClick={openNewMap}
            disabled={busy || !activeMap}
            title="新建一个独立的思维导图面板"
          >
            新建导图
          </button>
          <button
            type="button"
            onClick={() => setTheme((current) => (current === "dark" ? "light" : "dark"))}
            title="切换明暗主题"
          >
            {theme === "dark" ? "浅色主题" : "深色主题"}
          </button>
          <button
            type="button"
            onClick={() => {
              window.localStorage.removeItem(DOCK_LAYOUT_KEY);
              window.location.reload();
            }}
          >
            重置面板
          </button>
          <button type="button" onClick={checkBackend} disabled={busy}>
            检查后端
          </button>
        </div>
        <div className={`backend ${backend.startsWith("未") ? "offline" : "online"}`}>
          {backend}
        </div>
      </header>

      <div className="body">
        <main className="workspace">
          {error && <div className="error-banner">{error}</div>}
          <div className="dock-fill">
            <DockWorkspace
              ref={dockRef}
              workspace={workspace}
              activeMap={activeMap}
              selected={selected}
              logs={logs}
              onActiveNode={(node) => setSelected(node)}
              onPanelDirty={handlePanelDirty}
              onSelectNode={selectNode}
              onSwitchMap={switchMap}
            />
          </div>
        </main>
      </div>

      {searchOpen && workspace && (
        <SearchPalette
          workspace={workspace}
          onClose={() => setSearchOpen(false)}
          onOpenHit={openSearchHit}
        />
      )}
    </div>
  );
}

export default App;
