import type { LanguageSupport } from "@codemirror/language";

export async function loadLanguageExtension(
  language: string,
): Promise<LanguageSupport | null> {
  const name = language.trim().toLowerCase();
  if (!name) {
    return null;
  }

  switch (name) {
    case "rust":
    case "rs":
      return (await import("@codemirror/lang-rust")).rust();
    case "js":
    case "javascript":
      return (await import("@codemirror/lang-javascript")).javascript();
    case "jsx":
      return (await import("@codemirror/lang-javascript")).javascript({
        jsx: true,
      });
    case "ts":
    case "typescript":
      return (await import("@codemirror/lang-javascript")).javascript({
        typescript: true,
      });
    case "tsx":
      return (await import("@codemirror/lang-javascript")).javascript({
        jsx: true,
        typescript: true,
      });
    case "py":
    case "python":
      return (await import("@codemirror/lang-python")).python();
    case "json":
      return (await import("@codemirror/lang-json")).json();
    case "html":
      return (await import("@codemirror/lang-html")).html();
    case "css":
      return (await import("@codemirror/lang-css")).css();
    case "md":
    case "markdown":
      return (await import("@codemirror/lang-markdown")).markdown();
    default:
      return null;
  }
}
