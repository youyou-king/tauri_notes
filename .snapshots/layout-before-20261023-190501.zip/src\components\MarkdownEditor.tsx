import { useEffect, useRef } from "react";
import { EditorState } from "@codemirror/state";
import { EditorView } from "@codemirror/view";
import { createMarkdownExtensions } from "../editor/markdownExtensions";

const editorTheme = EditorView.theme({
  "&": {
    height: "100%",
    backgroundColor: "transparent",
    color: "var(--text)",
  },
  ".cm-scroller": {
    overflow: "auto",
    fontFamily: "var(--prose-font)",
    padding: "0",
  },
  ".cm-content": {
    maxWidth: "860px",
    margin: "0 auto",
    padding: "18px 48px 120px",
    fontSize: "16px",
    lineHeight: "1.8",
    color: "var(--text)",
    caretColor: "var(--accent)",
  },
  ".cm-line": {
    padding: "0",
  },
  ".cm-cursor, .cm-dropCursor": {
    borderLeftColor: "var(--accent)",
    borderLeftWidth: "2px",
  },
  "&.cm-focused .cm-cursor": {
    borderLeftColor: "var(--accent)",
  },
  ".cm-selectionBackground, ::selection": {
    background: "rgba(122, 162, 255, 0.24)",
  },
  "&.cm-focused .cm-selectionBackground": {
    background: "rgba(122, 162, 255, 0.3)",
  },
  ".cm-activeLine": {
    backgroundColor: "transparent",
  },
  ".cm-gutters": {
    display: "none",
  },
});

export default function MarkdownEditor({
  content,
  onChange,
  onSave,
}: {
  content: string;
  onChange: (content: string) => void;
  onSave: () => void;
}) {
  const hostRef = useRef<HTMLDivElement>(null);
  const viewRef = useRef<EditorView | null>(null);
  const onChangeRef = useRef(onChange);
  const onSaveRef = useRef(onSave);
  onChangeRef.current = onChange;
  onSaveRef.current = onSave;

  useEffect(() => {
    const host = hostRef.current;
    if (!host) {
      return;
    }

    const view = new EditorView({
      parent: host,
      state: EditorState.create({
        doc: content,
        extensions: [
          ...createMarkdownExtensions(() => onSaveRef.current()),
          editorTheme,
          EditorView.updateListener.of((update) => {
            if (update.docChanged) {
              onChangeRef.current(update.state.doc.toString());
            }
          }),
        ],
      }),
    });
    viewRef.current = view;
    // 不自动 focus：聚焦会让浏览器把 CodeMirror 滚动到光标处，
    // 文档加载后看起来像“从中间开始”。等用户点击再聚焦。
    const resetScroll = () => {
      view.scrollDOM.scrollTop = 0;
    };
    requestAnimationFrame(resetScroll);
    const scrollTimer = window.setTimeout(resetScroll, 120);

    return () => {
      window.clearTimeout(scrollTimer);
      view.destroy();
      viewRef.current = null;
    };
    // content 只在加载文档时作为初始值；后续编辑由 CodeMirror 自己持有。
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const view = viewRef.current;
    if (!view || view.hasFocus) {
      return;
    }
    if (view.state.doc.toString() !== content) {
      view.dispatch({
        changes: {
          from: 0,
          to: view.state.doc.length,
          insert: content,
        },
      });
    }
  }, [content]);

  return <div ref={hostRef} className="markdown-editor" />;
}
