import { indentLess, indentMore } from "@codemirror/commands";
import { syntaxTree } from "@codemirror/language";
import type { EditorState } from "@codemirror/state";
import type { Command, EditorView } from "@codemirror/view";
import type { SyntaxNode } from "@lezer/common";

function insideCode(state: EditorState, pos: number): boolean {
  let node: SyntaxNode | null = syntaxTree(state).resolveInner(pos, -1);
  while (node) {
    if (
      node.name === "FencedCode" ||
      node.name === "CodeBlock" ||
      node.name === "CodeText"
    ) {
      return true;
    }
    node = node.parent;
  }
  return false;
}

function orderedMarker(marker: string): string {
  if (!/^\d/.test(marker)) {
    return marker;
  }
  const number = Number.parseInt(marker, 10);
  const punctuation = marker.endsWith(")") ? ")" : ".";
  return `${number + 1}${punctuation}`;
}

function listPrefix(text: string) {
  return text.match(/^(\s*)([-+*]|\d+[.)])(\s+)(.*)$/);
}

function quotePrefix(text: string) {
  return text.match(/^(\s*)(>\s?)(.*)$/);
}

function continueList(view: EditorView): boolean {
  const state = view.state;
  const selection = state.selection.main;
  if (!selection.empty) {
    return false;
  }
  const line = state.doc.lineAt(selection.head);
  const offset = selection.head - line.from;
  if (insideCode(state, selection.head)) {
    return false;
  }

  const list = listPrefix(line.text);
  if (list) {
    const [prefix, indent, marker, spaces, content] = list;
    const contentStart =
      indent.length + marker.length + spaces.length;
    if (offset < contentStart) {
      return false;
    }
    const task = content.match(/^(\[[ xX]\])(\s+)(.*)$/);
    if (task && task[3].length === 0) {
      view.dispatch({
        changes: {
          from: line.from + indent.length,
          to: line.from + prefix.length,
          insert: "",
        },
        selection: { anchor: line.from + indent.length },
      });
      return true;
    }
    if (content.length === 0) {
      // 空列表项：回车退出列表，保留缩进。
      view.dispatch({
        changes: {
          from: line.from + indent.length,
          to: line.from + prefix.length,
          insert: "",
        },
        selection: { anchor: line.from + indent.length },
      });
      return true;
    }
    const next = orderedMarker(marker);
    const insert = task
      ? `\n${indent}${next}${spaces}[ ] `
      : `\n${indent}${next}${spaces}`;
    view.dispatch({
      changes: { from: selection.head, insert },
      selection: { anchor: selection.head + insert.length },
      scrollIntoView: true,
    });
    return true;
  }

  const quote = quotePrefix(line.text);
  if (quote && offset >= quote[1].length + quote[2].length) {
    const [prefix, indent, mark, content] = quote;
    if (content.length === 0) {
      view.dispatch({
        changes: {
          from: line.from + indent.length,
          to: line.from + prefix.length,
          insert: "",
        },
        selection: { anchor: line.from + indent.length },
      });
      return true;
    }
    const insert = `\n${indent}${mark}`;
    view.dispatch({
      changes: { from: selection.head, insert },
      selection: { anchor: selection.head + insert.length },
      scrollIntoView: true,
    });
    return true;
  }

  return false;
}

export const markdownEnter: Command = (view) => {
  const selection = view.state.selection.main;
  if (!selection.empty) {
    return false;
  }
  return continueList(view);
};

export const markdownShiftEnter: Command = (view) => {
  const selection = view.state.selection.main;
  if (!selection.empty) {
    return false;
  }
  if (continueList(view)) {
    return true;
  }
  view.dispatch({
    changes: { from: selection.head, insert: "\n" },
    selection: { anchor: selection.head + 1 },
    scrollIntoView: true,
  });
  return true;
};

function inList(state: EditorState, pos: number): boolean {
  const line = state.doc.lineAt(pos);
  return Boolean(listPrefix(line.text) || quotePrefix(line.text));
}

export const markdownTab: Command = (view) => {
  if (!inList(view.state, view.state.selection.main.head)) {
    return false;
  }
  return indentMore(view);
};

export const markdownShiftTab: Command = (view) => {
  if (!inList(view.state, view.state.selection.main.head)) {
    return false;
  }
  return indentLess(view);
};
