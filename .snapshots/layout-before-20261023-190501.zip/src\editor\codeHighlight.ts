import { HighlightStyle, syntaxHighlighting } from "@codemirror/language";
import { tags } from "@lezer/highlight";

export const markdownCodeHighlight = HighlightStyle.define([
  { tag: tags.keyword, color: "var(--code-keyword)" },
  {
    tag: [tags.string, tags.special(tags.string)],
    color: "var(--code-string)",
  },
  {
    tag: [tags.number, tags.bool, tags.null],
    color: "var(--code-number)",
  },
  {
    tag: [tags.comment, tags.lineComment, tags.blockComment],
    color: "var(--code-comment)",
    fontStyle: "italic",
  },
  {
    tag: [tags.function(tags.variableName), tags.function(tags.propertyName)],
    color: "var(--code-function)",
  },
  {
    tag: [tags.typeName, tags.className],
    color: "var(--code-type)",
  },
  {
    tag: [tags.propertyName, tags.attributeName, tags.operator],
    color: "var(--code-property)",
  },
  { tag: tags.variableName, color: "var(--code-text)" },
  { tag: tags.atom, color: "var(--code-number)" },
]);

export const markdownCodeHighlighting = syntaxHighlighting(
  markdownCodeHighlight,
);
