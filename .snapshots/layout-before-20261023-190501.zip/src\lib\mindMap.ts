import type { Edge, Node } from "@xyflow/react";
import type { NodeView } from "../types";

type MindMapNodeData = {
  label: string;
  hasDocument: boolean;
  selected: boolean;
};

const X_GAP = 230;
const Y_GAP = 128;

export function buildMindMap(
  root: NodeView,
  selectedId: string | null,
): { nodes: Node<MindMapNodeData>[]; edges: Edge[] } {
  const nodes: Node<MindMapNodeData>[] = [];
  const edges: Edge[] = [];
  let cursor = 0;

  function place(node: NodeView, depth: number): number {
    let x: number;
    if (node.children.length === 0) {
      x = cursor * X_GAP;
      cursor += 1;
    } else {
      const childXs = node.children.map((child) => place(child, depth + 1));
      x = (childXs[0] + childXs[childXs.length - 1]) / 2;
    }

    nodes.push({
      id: node.id,
      position: { x, y: depth * Y_GAP },
      data: {
        label: node.title,
        hasDocument: node.hasDocument,
        selected: node.id === selectedId,
      },
      type: "default",
      style: {
        width: 190,
        padding: "10px 12px",
        borderRadius: 10,
        border: `1px solid ${node.id === selectedId ? "#7aa2ff" : "#344056"}`,
        background: node.id === selectedId ? "#1d2b43" : "#171c26",
        color: "#dbe2ef",
        fontSize: 13,
      },
    });

    for (const child of node.children) {
      edges.push({
        id: `${node.id}->${child.id}`,
        source: node.id,
        target: child.id,
        type: "smoothstep",
        style: { stroke: "#43516b", strokeWidth: 1.5 },
      });
    }

    return x;
  }

  place(root, 0);
  return { nodes, edges };
}
