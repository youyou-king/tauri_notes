import { useEffect } from "react";
import type { DockviewPanelApi } from "dockview-react";
import MarkdownEditor from "./MarkdownEditor";
import { useMarkdownDocument } from "../hooks/useMarkdownDocument";
import type { MapView, NodeView, WorkspaceView } from "../types";

export default function DocumentPane({
  workspace,
  map,
  node,
  panelApi,
  onDirtyChange,
}: {
  workspace: WorkspaceView | null;
  map: MapView | null;
  node: NodeView | null;
  active: boolean;
  panelApi: DockviewPanelApi;
  onDirtyChange: (dirty: boolean) => void;
}) {
  const session = useMarkdownDocument({
    workspace,
    map,
    node,
    onDirtyChange,
  });

  useEffect(() => {
    panelApi.setTitle(`${session.dirty ? "• " : ""}${node?.title ?? "文档"}`);
  }, [panelApi, session.dirty, node?.title]);

  if (!session.document) {
    return (
      <div className="editor-placeholder">
        <h1>{node?.title ?? "选择一篇文档"}</h1>
        <p>
          {node && !node.hasDocument
            ? "这个节点还没有 docs/<node>.md。"
            : "点击左侧节点读取 Markdown，或 Shift+点击在新面板打开。"}
        </p>
      </div>
    );
  }

  return (
    <div className="document-shell">
      {session.error && <div className="error-banner">{session.error}</div>}
      <div className="document-meta">
        {session.document.path} · CodeMirror ·{" "}
        {session.length.toLocaleString()} 字符
        {session.saving ? " · 保存中…" : session.dirty ? " · 未保存" : ""}
      </div>
      <MarkdownEditor
        key={`${session.document.path}:${session.revision}`}
        content={session.document.content}
        onChange={session.change}
        onSave={session.saveNow}
      />
    </div>
  );
}
