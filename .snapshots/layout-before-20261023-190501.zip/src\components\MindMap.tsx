import { useEffect, useMemo } from "react";
import {
  Background,
  Controls,
  MiniMap,
  ReactFlow,
  ReactFlowProvider,
  useReactFlow,
  type NodeMouseHandler,
} from "@xyflow/react";
import type { MapView, NodeView } from "../types";
import { buildMindMap } from "../lib/mindMap";

function descendants(root: NodeView): NodeView[] {
  return [root, ...root.children.flatMap(descendants)];
}

function MindMapInner({
  map,
  selectedId,
  onSelect,
}: {
  map: MapView;
  selectedId: string | null;
  onSelect: (node: NodeView) => void;
}) {
  const { fitView } = useReactFlow();
  const graph = useMemo(
    () => buildMindMap(map.root, selectedId),
    [map.root, selectedId],
  );
  const byId = useMemo(
    () => new Map(descendants(map.root).map((node) => [node.id, node])),
    [map.root],
  );

  useEffect(() => {
    const frame = requestAnimationFrame(() => {
      void fitView({ padding: 0.25, duration: 220 });
    });
    return () => cancelAnimationFrame(frame);
  }, [map.id, fitView]);

  const onNodeClick: NodeMouseHandler = (_, node) => {
    const target = byId.get(node.id);
    if (target) {
      onSelect(target);
    }
  };

  return (
    <ReactFlow
      nodes={graph.nodes}
      edges={graph.edges}
      onNodeClick={onNodeClick}
      fitView
      minZoom={0.2}
      maxZoom={1.8}
      nodesConnectable={false}
      edgesFocusable={false}
      proOptions={{ hideAttribution: true }}
      className="mind-map-flow"
    >
      <Background color="#2a3345" gap={24} size={1} />
      <Controls showInteractive={false} />
      <MiniMap
        pannable
        zoomable
        nodeColor="#2d3b55"
        maskColor="rgba(8, 11, 16, 0.72)"
      />
    </ReactFlow>
  );
}

export default function MindMap({
  map,
  selectedId,
  onSelect,
}: {
  map: MapView;
  selectedId: string | null;
  onSelect: (node: NodeView) => void;
}) {
  return (
    <div className="mind-map">
      <ReactFlowProvider>
        <MindMapInner map={map} selectedId={selectedId} onSelect={onSelect} />
      </ReactFlowProvider>
    </div>
  );
}
