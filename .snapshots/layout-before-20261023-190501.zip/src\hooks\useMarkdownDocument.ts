import { useCallback, useEffect, useRef, useState } from "react";
import { invoke } from "@tauri-apps/api/core";
import type { DocumentView, MapView, NodeView, WorkspaceView } from "../types";

export type MarkdownDocumentSession = {
  document: DocumentView | null;
  dirty: boolean;
  saving: boolean;
  error: string | null;
  length: number;
  revision: number;
  change: (content: string) => void;
  saveNow: () => void;
};

const AUTOSAVE_DELAY = 700;

export function useMarkdownDocument({
  workspace,
  map,
  node,
  onDirtyChange,
}: {
  workspace: WorkspaceView | null;
  map: MapView | null;
  node: NodeView | null;
  onDirtyChange: (dirty: boolean) => void;
}): MarkdownDocumentSession {
  const [document, setDocument] = useState<DocumentView | null>(null);
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [length, setLength] = useState(0);
  const [revision, setRevision] = useState(0);
  const contentRef = useRef("");
  const savedRef = useRef("");
  const modifiedRef = useRef(0);
  const loadedRef = useRef(false);
  const dirtyRef = useRef(false);
  const timerRef = useRef<number | null>(null);
  const saveRef = useRef<() => void>(() => {});

  const clearTimer = useCallback(() => {
    if (timerRef.current !== null) {
      window.clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const setDirtyState = useCallback((value: boolean) => {
    dirtyRef.current = value;
    setDirty(value);
  }, []);

  const saveNow = useCallback(async () => {
    clearTimer();
    if (!workspace || !map || !node || !loadedRef.current) {
      return;
    }
    const value = contentRef.current;
    if (value === savedRef.current) {
      setDirtyState(false);
      return;
    }

    setSaving(true);
    setError(null);
    try {
      await invoke("write_document", {
        workspace: workspace.root,
        mapId: map.id,
        nodeId: node.id,
        content: value,
      });
      savedRef.current = value;
      try {
        modifiedRef.current = await invoke<number>("document_modified", {
          workspace: workspace.root,
          mapId: map.id,
          nodeId: node.id,
        });
      } catch {
        // 修改时间读取失败不影响保存结果。
      }
      if (contentRef.current === value) {
        setDirtyState(false);
      }
    } catch (err) {
      setError(String(err));
    } finally {
      setSaving(false);
    }
  }, [clearTimer, map, node, setDirtyState, workspace]);

  saveRef.current = () => {
    void saveNow();
  };

  useEffect(() => {
    let cancelled = false;
    clearTimer();
    setDocument(null);
    setDirtyState(false);
    setSaving(false);
    setError(null);
    loadedRef.current = false;
    contentRef.current = "";
    savedRef.current = "";

    if (!workspace || !map || !node || !node.hasDocument) {
      return;
    }

    invoke<DocumentView>("read_document", {
      workspace: workspace.root,
      mapId: map.id,
      nodeId: node.id,
    })
      .then((next) => {
        if (cancelled) {
          return;
        }
        setDocument(next);
        contentRef.current = next.content;
        savedRef.current = next.content;
        modifiedRef.current = next.modified;
        loadedRef.current = true;
        setLength(next.content.length);
        setDirtyState(false);
      })
      .catch((err) => {
        if (!cancelled) {
          setError(String(err));
        }
      });

    return () => {
      cancelled = true;
    };
  }, [clearTimer, map, node, setDirtyState, workspace]);

  useEffect(() => {
    onDirtyChange(dirty);
  }, [dirty, onDirtyChange]);

  useEffect(() => {
    if (!document || !workspace || !map || !node) {
      return;
    }
    let cancelled = false;
    const timer = window.setInterval(() => {
      if (cancelled || dirtyRef.current || !loadedRef.current) {
        return;
      }
      void invoke<number>("document_modified", {
        workspace: workspace.root,
        mapId: map.id,
        nodeId: node.id,
      })
        .then(async (modified) => {
          if (cancelled || modified <= modifiedRef.current) {
            return;
          }
          const next = await invoke<DocumentView>("read_document", {
            workspace: workspace.root,
            mapId: map.id,
            nodeId: node.id,
          });
          if (cancelled || dirtyRef.current) {
            return;
          }
          modifiedRef.current = next.modified;
          contentRef.current = next.content;
          savedRef.current = next.content;
          setDocument(next);
          setLength(next.content.length);
          setDirtyState(false);
          setRevision((value) => value + 1);
        })
        .catch(() => {
          // 文件被删除或暂时不可读时不打断编辑。
        });
    }, 2500);
    return () => {
      cancelled = true;
      window.clearInterval(timer);
    };
  }, [document?.path, map?.id, node?.id, setDirtyState, workspace?.root]);

  useEffect(() => {
    return () => {
      clearTimer();
      if (dirtyRef.current && loadedRef.current && contentRef.current !== savedRef.current) {
        const pending = contentRef.current;
        if (workspace && map && node) {
          void invoke("write_document", {
            workspace: workspace.root,
            mapId: map.id,
            nodeId: node.id,
            content: pending,
          }).catch(() => {
            // 组件卸载时无法展示错误；下次打开会从磁盘重新读取。
          });
        }
      }
    };
  }, [clearTimer, map, node, workspace]);

  const change = useCallback(
    (content: string) => {
      contentRef.current = content;
      setLength(content.length);
      if (content === savedRef.current) {
        setDirtyState(false);
        clearTimer();
        return;
      }
      setDirtyState(true);
      clearTimer();
      timerRef.current = window.setTimeout(() => {
        saveRef.current();
      }, AUTOSAVE_DELAY);
    },
    [clearTimer, setDirtyState],
  );

  return {
    document,
    dirty,
    saving,
    error,
    length,
    revision,
    change,
    saveNow: () => {
      void saveNow();
    },
  };
}
