import { syntaxTree } from "@codemirror/language";
import { EditorState, type Extension, type Range, StateField } from "@codemirror/state";
import {
  Decoration,
  type DecorationSet,
  EditorView,
  ViewPlugin,
  type ViewUpdate,
  WidgetType,
} from "@codemirror/view";

type DecoRange = {
  from: number;
  to: number;
  deco: Decoration;
};

class ListMarkerWidget extends WidgetType {
  constructor(readonly text: string) {
    super();
  }

  eq(other: ListMarkerWidget) {
    return other.text === this.text;
  }

  toDOM() {
    const span = document.createElement("span");
    span.className = "cm-md-list-mark";
    span.textContent = this.text;
    return span;
  }
}

class TaskCheckboxWidget extends WidgetType {  constructor(
    readonly checked: boolean,
    readonly from: number,
  ) {
    super();
  }

  eq(other: TaskCheckboxWidget) {
    return other.checked === this.checked && other.from === this.from;
  }

  toDOM(view: EditorView) {
    const input = document.createElement("input");
    input.type = "checkbox";
    input.className = "cm-md-task-checkbox";
    input.checked = this.checked;
    input.setAttribute("aria-label", this.checked ? "标记为未完成" : "标记为完成");
    input.addEventListener("change", () => {
      view.dispatch({
        changes: {
          from: this.from + 1,
          to: this.from + 2,
          insert: this.checked ? " " : "x",
        },
      });
      view.focus();
    });
    return input;
  }
}

class HorizontalRuleWidget extends WidgetType {
  constructor(readonly from: number) {
    super();
  }

  eq(other: HorizontalRuleWidget) {
    return other.from === this.from;
  }

  toDOM(view: EditorView) {
    const line = document.createElement("span");
    line.className = "cm-md-hr-widget";
    line.setAttribute("aria-label", "分割线");
    line.title = "点击编辑分割线";
    line.addEventListener("mousedown", (event) => {
      event.preventDefault();
      view.focus();
      view.dispatch({
        selection: { anchor: this.from },
        scrollIntoView: true,
      });
    });
    return line;
  }
}

type ParsedTable = {
  header: string[];
  rows: string[][];
  aligns: Array<"left" | "center" | "right" | null>;
};

type TableBlock = {
  from: number;
  to: number;
  source: string;
  parsed: ParsedTable;
};

function splitTableRow(text: string): string[] {
  let value = text.trim();
  if (value.startsWith("|")) {
    value = value.slice(1);
  }
  if (value.endsWith("|")) {
    value = value.slice(0, -1);
  }
  return value.split("|").map((cell) => cell.trim());
}

function parseTable(source: string): ParsedTable | null {  const lines = source.split("\n").filter((line) => line.trim().length > 0);
  if (lines.length < 2) {
    return null;
  }
  const header = splitTableRow(lines[0]);
  const separator = splitTableRow(lines[1]);
  if (
    header.length === 0 ||
    separator.length !== header.length ||
    !separator.every((cell) => /^:?-{3,}:?$/.test(cell))
  ) {
    return null;
  }
  const aligns = separator.map((cell) => {
    const left = cell.startsWith(":");
    const right = cell.endsWith(":");
    if (left && right) return "center";
    if (right) return "right";
    if (left) return "left";
    return null;
  });
  const rows = lines
    .slice(2)
    .map(splitTableRow)
    .map((row) => {
      while (row.length < header.length) row.push("");
      return row.slice(0, header.length);
    });
  return { header, rows, aligns };
}

function findTables(state: EditorState): TableBlock[] {
  // 超大文档不做整篇表格扫描，避免每次输入都 O(文档) 遍历；表格保留源码显示。
  if (state.doc.length > 200_000) {
    return [];
  }
  const tables: TableBlock[] = [];
  let number = 1;
  while (number <= state.doc.lines) {
    const line = state.doc.line(number);
    if (!line.text.trim().startsWith("|")) {
      number += 1;
      continue;
    }

    const lines: string[] = [];
    let current = line;
    let lastTableLine = line;
    while (current.text.trim().startsWith("|")) {
      lines.push(current.text);
      lastTableLine = current;
      if (current.number >= state.doc.lines) {
        break;
      }
      current = state.doc.line(current.number + 1);
    }
    const source = lines.join("\n");
    const parsed = parseTable(source);
    if (parsed) {
      tables.push({
        from: line.from,
        to: lastTableLine.to,
        source,
        parsed,
      });
      number = lastTableLine.number + 1;
    } else {
      number += 1;
    }
  }
  return tables;
}

class TableWidget extends WidgetType {
  constructor(
    readonly source: string,
    readonly from: number,
    readonly to: number,
    readonly parsed: ParsedTable,
  ) {
    super();
  }

  eq(other: TableWidget) {
    return other.source === this.source;
  }

  toDOM(view: EditorView) {
    const wrapper = document.createElement("div");
    wrapper.className = "cm-md-table-widget";
    wrapper.dataset.tableFrom = String(this.from);
    let suppressCommit = false;

    const table = document.createElement("table");
    const thead = document.createElement("thead");
    const headRow = document.createElement("tr");
    const tbody = document.createElement("tbody");
    const alignFor = (index: number) => this.parsed.aligns[index] ?? null;

    const input = (value: string, align: string | null) => {
      const cellInput = document.createElement("input");
      cellInput.className = "cm-md-table-cell";
      cellInput.value = value;
      cellInput.spellcheck = false;
      if (align) {
        cellInput.style.textAlign = align;
      }
      cellInput.addEventListener("keydown", (event) => {
        if (event.key === "Enter") {
          event.preventDefault();
          cellInput.blur();
        }
      });
      return cellInput;
    };

    this.parsed.header.forEach((cell, index) => {
      const th = document.createElement("th");
      th.appendChild(input(cell, alignFor(index)));
      headRow.appendChild(th);
    });
    thead.appendChild(headRow);
    table.appendChild(thead);

    this.parsed.rows.forEach((row) => {
      const tr = document.createElement("tr");
      row.forEach((cell, index) => {
        const td = document.createElement("td");
        td.appendChild(input(cell, alignFor(index)));
        tr.appendChild(td);
      });
      tbody.appendChild(tr);
    });
    table.appendChild(tbody);
    wrapper.appendChild(table);

    const readCells = () => {
      const header = Array.from(
        headRow.querySelectorAll<HTMLInputElement>("input"),
      ).map((cell) => cell.value);
      const rows = Array.from(
        tbody.querySelectorAll<HTMLTableRowElement>("tr"),
      ).map((tr) =>
        Array.from(tr.querySelectorAll<HTMLInputElement>("input")).map(
          (cell) => cell.value,
        ),
      );
      return { header, rows };
    };

    const separator = (aligns: Array<string | null>) => {
      const cells = aligns.map((align) => {
        if (align === "center") return ":---:";
        if (align === "right") return "---:";
        if (align === "left") return ":---";
        return "---";
      });
      return `| ${cells.join(" | ")} |`;
    };

    const writeTable = (
      header: string[],
      rows: string[][],
      aligns: Array<string | null>,
      focus?: { row: number; col: number },
    ) => {
      const escape = (value: string) => value.replace(/\|/g, "\\|");
      const headerLine = `| ${header.map(escape).join(" | ")} |`;
      const bodyLines = rows.map(
        (row) => `| ${row.map(escape).join(" | ")} |`,
      );
      const next = [headerLine, separator(aligns), ...bodyLines].join("\n");
      if (next !== this.source) {
        view.dispatch({
          changes: { from: this.from, to: this.to, insert: next },
        });
      }
      if (!focus) {
        return;
      }
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          const root =
            view.dom.querySelector<HTMLElement>(
              `.cm-md-table-widget[data-table-from="${this.from}"]`,
            ) ?? wrapper;
          const rowsInDom = Array.from(root.querySelectorAll("tr"));
          const targetRow = focus.row < 0 ? 0 : focus.row + 1;
          const target = rowsInDom[targetRow]?.querySelectorAll("input")[
            focus.col
          ] as HTMLInputElement | undefined;
          target?.focus();
          target?.select();
        });
      });
    };

    const addRow = (atTop: boolean) => {
      const { header, rows } = readCells();
      const empty = new Array(header.length).fill("");
      const nextRows = atTop ? [empty, ...rows] : [...rows, empty];
      suppressCommit = true;
      writeTable(
        header,
        nextRows,
        header.map((_, index) => alignFor(index)),
        { row: atTop ? 0 : nextRows.length - 1, col: 0 },
      );
    };

    const addColumn = (atStart: boolean) => {
      const { header, rows } = readCells();
      const nextHeader = atStart ? ["", ...header] : [...header, ""];
      const nextRows = rows.map((row) =>
        atStart ? ["", ...row] : [...row, ""],
      );
      const aligns = nextHeader.map((_, index) => {
        if (atStart) {
          return index === 0 ? null : alignFor(index - 1);
        }
        return alignFor(index);
      });
      suppressCommit = true;
      writeTable(nextHeader, nextRows, aligns, {
        row: nextRows.length > 0 ? 0 : -1,
        col: atStart ? 0 : nextHeader.length - 1,
      });
    };

    const addButton = (className: string, label: string, onClick: () => void) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = `cm-md-table-add ${className}`;
      button.textContent = "+";
      button.title = label;
      button.setAttribute("aria-label", label);
      button.addEventListener("mousedown", (event) => event.preventDefault());
      button.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        onClick();
      });
      wrapper.appendChild(button);
    };

    addButton("cm-md-table-add-top", "在上方添加一行", () => addRow(true));
    addButton("cm-md-table-add-bottom", "在下方添加一行", () =>
      addRow(false),
    );
    addButton("cm-md-table-add-left", "在左侧添加一列", () =>
      addColumn(true),
    );
    addButton("cm-md-table-add-right", "在右侧添加一列", () =>
      addColumn(false),
    );

    const commit = () => {
      const { header, rows } = readCells();
      writeTable(header, rows, header.map((_, index) => alignFor(index)));
    };

    wrapper.addEventListener("focusout", (event) => {
      if (suppressCommit) {
        return;
      }
      const next = event.relatedTarget;
      if (next instanceof Node && wrapper.contains(next)) {
        return;
      }
      commit();
    });
    wrapper.addEventListener("mousedown", (event) => {
      const target = event.target as HTMLElement;
      if (target.closest("input") || target.closest("button")) {
        return;
      }
      event.preventDefault();
      view.focus();
      view.dispatch({
        selection: { anchor: this.from },
        scrollIntoView: true,
      });
    });

    return wrapper;
  }
}

function buildTableDecorations(state: EditorState): DecorationSet {
  const items = findTables(state)
    .filter((table) => !selectionTouches(state, table.from, table.to))
    .map((table) =>
      Decoration.replace({
        widget: new TableWidget(table.source, table.from, table.to, table.parsed),
        block: true,
      }).range(table.from, table.to),
    );
  return Decoration.set(items, true);
}

const tableField = StateField.define<DecorationSet>({
  create: buildTableDecorations,
  update(value, transaction) {
    if (!transaction.docChanged && !transaction.selection) {
      return value;
    }
    return buildTableDecorations(transaction.state);
  },
  provide: (field) => EditorView.decorations.from(field),
});

function selectionTouches(state: EditorState, from: number, to: number): boolean {
  return state.selection.ranges.some(
    (range) => range.from <= to && range.to >= from,
  );
}

function addLine(ranges: DecoRange[], seen: Set<number>, from: number, cls: string) {
  if (seen.has(from)) {
    return;
  }
  seen.add(from);
  ranges.push({
    from,
    to: from,
    deco: Decoration.line({ class: cls }),
  });
}

function addHiddenMark(
  ranges: DecoRange[],
  state: EditorState,
  from: number,
  to: number,
) {
  if (from >= to) {
    return;
  }
  // 隐藏定界符时连同其后一个空格一起隐藏，避免标题/列表前出现孤立空格。
  const next = state.doc.sliceString(to, to + 1);
  ranges.push({
    from,
    to: next === " " ? to + 1 : to,
    deco: Decoration.replace({}),
  });
}

function buildDecorations(view: EditorView): DecorationSet {
  const { state } = view;
  const ranges: DecoRange[] = [];
  const seenLines = new Set<number>();
  const tree = syntaxTree(state);

  for (const visible of view.visibleRanges) {
    let line = state.doc.lineAt(
      Math.max(0, Math.min(visible.from, state.doc.length)),
    );
    while (line.from <= visible.to) {
      const task = line.text.match(
        /^(\s*)([-+*]|\d+[.)])(\s+)\[([ xX])\]/,
      );
      if (
        task &&
        !selectionTouches(state, line.from, line.to)
      ) {
        const from =
          line.from + task[1].length + task[2].length + task[3].length;
        ranges.push({
          from,
          to: from + 3,
          deco: Decoration.replace({
            widget: new TaskCheckboxWidget(task[4].toLowerCase() === "x", from),
          }),
        });
      }
      if (line.to >= state.doc.length) {
        break;
      }
      line = state.doc.lineAt(line.to + 1);
    }
  }

  for (const visible of view.visibleRanges) {
    tree.iterate({
      from: visible.from,
      to: visible.to,
      enter: (node) => {
        const name = node.name;

        if (name === "HorizontalRule") {
          const line = state.doc.lineAt(node.from);
          if (!selectionTouches(state, line.from, line.to)) {
            ranges.push({
              from: line.from,
              to: line.to,
              deco: Decoration.replace({
                widget: new HorizontalRuleWidget(line.from),
              }),
            });
          }
        }

        if (/^ATXHeading[1-6]$/.test(name)) {
          const level = Number(name.slice(-1));
          const line = state.doc.lineAt(node.from);
          addLine(ranges, seenLines, line.from, `cm-md-heading cm-md-h${level}`);
          if (!selectionTouches(state, line.from, line.to)) {
            for (let child = node.node.firstChild; child; child = child.nextSibling) {
              if (child.name === "HeaderMark") {
                addHiddenMark(ranges, state, child.from, child.to);
              }
            }
          }
        }

        if (name === "Blockquote") {
          let pos = Math.max(node.from, visible.from);
          while (pos <= node.to) {
            const line = state.doc.lineAt(pos);
            addLine(ranges, seenLines, line.from, "cm-md-quote");
            if (!selectionTouches(state, line.from, line.to)) {
              const match = line.text.match(/^\s*>\s?/);
              if (match) {
                addHiddenMark(
                  ranges,
                  state,
                  line.from,
                  line.from + match[0].length,
                );
              }
            }
            if (line.to >= node.to) {
              break;
            }
            pos = line.to + 1;
          }
        }

        if (name === "FencedCode") {
          let pos = Math.max(node.from, visible.from);
          let first = true;
          while (pos <= node.to) {
            const line = state.doc.lineAt(pos);
            const last = line.to >= node.to;
            addLine(
              ranges,
              seenLines,
              line.from,
              `cm-md-code${first ? " cm-md-code-first" : ""}${
                last ? " cm-md-code-last" : ""
              }`,
            );
            first = false;
            if (
              !selectionTouches(state, line.from, line.to) &&
              /^\s*(```|~~~)/.test(line.text)
            ) {
              const marker = line.text.match(/^\s*(```|~~~)[^\n]*/);
              if (marker) {
                addHiddenMark(
                  ranges,
                  state,
                  line.from,
                  line.from + marker[0].length,
                );
              }
            }
            if (last) {
              break;
            }
            pos = line.to + 1;
          }
        }

        if (name === "ListMark") {
          const line = state.doc.lineAt(node.from);
          if (!selectionTouches(state, line.from, line.to)) {
            const raw = state.doc.sliceString(node.from, node.to);
            const marker = /^\d/.test(raw) ? `${raw} ` : "• ";
            ranges.push({
              from: node.from,
              to: node.to,
              deco: Decoration.replace({
                widget: new ListMarkerWidget(marker),
              }),
            });
          }
        }

        if (name === "StrongEmphasis") {
          ranges.push({
            from: node.from,
            to: node.to,
            deco: Decoration.mark({ class: "cm-md-strong" }),
          });
          if (!selectionTouches(state, node.from, node.to)) {
            for (let child = node.node.firstChild; child; child = child.nextSibling) {
              if (child.name === "EmphasisMark") {
                addHiddenMark(ranges, state, child.from, child.to);
              }
            }
          }
        }

        if (name === "Emphasis") {
          ranges.push({
            from: node.from,
            to: node.to,
            deco: Decoration.mark({ class: "cm-md-em" }),
          });
          if (!selectionTouches(state, node.from, node.to)) {
            for (let child = node.node.firstChild; child; child = child.nextSibling) {
              if (child.name === "EmphasisMark") {
                addHiddenMark(ranges, state, child.from, child.to);
              }
            }
          }
        }

        if (name === "InlineCode") {
          ranges.push({
            from: node.from,
            to: node.to,
            deco: Decoration.mark({ class: "cm-md-inline-code" }),
          });
          if (!selectionTouches(state, node.from, node.to)) {
            for (let child = node.node.firstChild; child; child = child.nextSibling) {
              if (child.name === "CodeMark" || child.name === "CodeText") {
                if (child.name === "CodeMark") {
                  addHiddenMark(ranges, state, child.from, child.to);
                }
              }
            }
          }
        }

        if (name === "Link" || name === "Image") {
          ranges.push({
            from: node.from,
            to: node.to,
            deco: Decoration.mark({ class: "cm-md-link" }),
          });
          if (!selectionTouches(state, node.from, node.to)) {
            for (let child = node.node.firstChild; child; child = child.nextSibling) {
              if (
                child.name === "LinkMark" ||
                child.name === "URL" ||
                child.name === "LinkTitle"
              ) {
                addHiddenMark(ranges, state, child.from, child.to);
              }
            }
          }
        }
      },
    });
  }

  const sorted = ranges.sort(
    (left, right) => left.from - right.from || left.to - right.to,
  );
  const items: Range<Decoration>[] = sorted.map((item) =>
    item.deco.range(item.from, item.to),
  );
  return Decoration.set(items, true);
}

const livePreviewPlugin = ViewPlugin.fromClass(
  class {
    decorations: DecorationSet;

    constructor(view: EditorView) {
      this.decorations = buildDecorations(view);
    }

    update(update: ViewUpdate) {
      if (
        update.docChanged ||
        update.selectionSet ||
        update.viewportChanged
      ) {
        this.decorations = buildDecorations(update.view);
      }
    }
  },
  {
    decorations: (value) => value.decorations,
  },
);

export function livePreview(): Extension {
  return [livePreviewPlugin, tableField];
}
