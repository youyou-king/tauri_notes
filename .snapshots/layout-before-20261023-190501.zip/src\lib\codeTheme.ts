import { HighlightStyle, syntaxHighlighting } from "@codemirror/language";
import { EditorView } from "@codemirror/view";
import { tags } from "@lezer/highlight";

export const codeHighlight = HighlightStyle.define([
  { tag: tags.keyword, color: "var(--code-keyword)" },
  {
    tag: [tags.string, tags.special(tags.string)],
    color: "var(--code-string)",
  },
  {
    tag: [tags.number, tags.bool, tags.null],
    color: "var(--code-number)",
  },
  {
    tag: [tags.comment, tags.lineComment, tags.blockComment],
    color: "var(--code-comment)",
    fontStyle: "italic",
  },
  {
    tag: [tags.function(tags.variableName), tags.function(tags.propertyName)],
    color: "var(--code-function)",
  },
  {
    tag: [tags.typeName, tags.className],
    color: "var(--code-type)",
  },
  {
    tag: [tags.propertyName, tags.attributeName],
    color: "var(--code-property)",
  },
  { tag: tags.operator, color: "var(--code-property)" },
  { tag: tags.heading, color: "var(--code-function)", fontWeight: "700" },
  {
    tag: tags.link,
    color: "var(--code-function)",
    textDecoration: "underline",
  },
]);

export const codeEditorTheme = EditorView.theme({
  "&": {
    background: "var(--code-bg)",
    color: "var(--code-text)",
    border: "1px solid var(--code-bg)",
    borderRadius: "9px",
    fontSize: "var(--code-size)",
  },
  ".cm-content": {
    fontFamily: "var(--code-font)",
    fontSize: "var(--code-size)",
    lineHeight: "var(--code-line-height)",
    padding: "14px 0",
    color: "var(--code-text)",
    caretColor: "var(--code-text)",
  },
  ".cm-cursor, .cm-dropCursor": {
    borderLeftColor: "var(--code-text)",
    borderLeftWidth: "2px",
  },
  "&.cm-focused .cm-cursor": {
    borderLeftColor: "var(--code-text)",
  },
  ".cm-selectionBackground, ::selection": {
    background: "rgba(122, 162, 255, 0.28)",
  },
  "&.cm-focused .cm-selectionBackground": {
    background: "rgba(122, 162, 255, 0.32)",
  },
  ".cm-line": {
    padding: "0 16px 0 4px",
  },
  ".cm-gutters": {
    background: "var(--code-bg)",
    color: "var(--code-comment)",
    border: "none",
    paddingLeft: "8px",
  },
  ".cm-activeLine": { background: "transparent" },
  ".cm-activeLineGutter": { background: "transparent" },
  ".cm-scroller": { maxHeight: "60vh", overflow: "auto" },
});

export const codeSyntaxHighlighting = syntaxHighlighting(codeHighlight);
