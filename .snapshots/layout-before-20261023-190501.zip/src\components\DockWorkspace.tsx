import {
  createContext,
  forwardRef,
  useCallback,
  useContext,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from "react";
import {
  DockviewReact,
  themeAbyss,
  type DockviewApi,
  type DockviewReadyEvent,
  type IDockviewPanelHeaderProps,
  type IDockviewPanelProps,
} from "dockview-react";
import DocumentPane from "./DocumentPane";
import MindMap from "./MindMap";
import type { MapView, NodeView, WorkspaceView } from "../types";

type DocParams = {
  mapId?: string;
  nodeId?: string;
};

type MapParams = {
  mapId?: string;
};

type PanelContextValue = {
  workspace: WorkspaceView | null;
  activeMap: MapView | null;
  activePanelId: string | null;
  selected: NodeView | null;
  logs: string[];
  openDocument: (mapId: string, nodeId: string) => void;
  setPanelDirty: (panelId: string, dirty: boolean) => void;
  onSelectNode: (node: NodeView, newPanel: boolean) => void;
  onSwitchMap: (map: MapView) => void;
};

const PanelContext = createContext<PanelContextValue | null>(null);

export const DOCK_LAYOUT_KEY = "tauri-notes.dock-layout.v13";

export type DockWorkspaceHandle = {
  openDocument: (mapId: string, nodeId: string) => void;
  openMap: (mapId: string, newPanel?: boolean) => void;
};

function findNode(node: NodeView, id: string): NodeView | null {
  if (node.id === id) {
    return node;
  }
  for (const child of node.children) {
    const found = findNode(child, id);
    if (found) {
      return found;
    }
  }
  return null;
}

function NodeTree({
  node,
  selectedId,
  onSelect,
}: {
  node: NodeView;
  selectedId: string | null;
  onSelect: (node: NodeView, newPanel: boolean) => void;
}) {
  return (
    <div className="tree-group">
      <button
        type="button"
        className={`tree-row ${selectedId === node.id ? "selected" : ""} ${
          node.children.length > 0 ? "branch" : "leaf"
        }`}
        onClick={(event) => onSelect(node, event.shiftKey)}
        title="点击打开文档；已打开则聚焦，否则新建文档面板"
      >
        <span className="tree-caret">{node.children.length > 0 ? "▾" : "·"}</span>
        <span>{node.title}</span>
        {node.hasDocument && <span className="doc-dot" title="有文档" />}
      </button>
      {node.children.length > 0 && (
        <div className="tree-children">
          {node.children.map((child) => (
            <NodeTree
              key={child.id}
              node={child}
              selectedId={selectedId}
              onSelect={onSelect}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function OutlinePanel() {
  const context = useContext(PanelContext);
  if (!context) {
    return null;
  }
  return (
    <div className="outline-panel">
      <div className="outline-title">{context.workspace?.title ?? "知识库"}</div>
      <div className="tree outline-tree">
        {context.activeMap ? (
          <NodeTree
            node={context.activeMap.root}
            selectedId={context.selected?.id ?? null}
            onSelect={context.onSelectNode}
          />
        ) : (
          <div className="empty-tree">还没有打开 `.notes` 工程</div>
        )}
      </div>
      {context.workspace && context.workspace.maps.length > 1 && (
        <div className="map-switcher">
          {context.workspace.maps.map((map) => (
            <button
              key={map.id}
              type="button"
              className={map.id === context.activeMap?.id ? "active" : ""}
              onClick={() => context.onSwitchMap(map)}
            >
              {map.title}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function DocumentPanel(props: IDockviewPanelProps<DocParams>) {
  const context = useContext(PanelContext);
  const map =
    context?.workspace?.maps.find(
      (item) => item.id === props.params?.mapId,
    ) ?? null;
  const node =
    map && props.params?.nodeId
      ? findNode(map.root, props.params.nodeId)
      : null;
  const handleDirty = useCallback(
    (dirty: boolean) => {
      context?.setPanelDirty(props.api.id, dirty);
    },
    [context, props.api.id],
  );

  useEffect(() => {
    return () => handleDirty(false);
  }, [handleDirty]);

  if (!context) {
    return null;
  }

  return (
    <DocumentPane
      workspace={context.workspace}
      map={map}
      node={node}
      active={context.activePanelId === props.api.id}
      panelApi={props.api}
      onDirtyChange={handleDirty}
    />
  );
}

function MapPanel(props: IDockviewPanelProps<MapParams>) {
  const context = useContext(PanelContext);
  if (!context) {
    return null;
  }
  const paramMap = props.params?.mapId
    ? context.workspace?.maps.find((item) => item.id === props.params?.mapId)
    : null;
  const map = paramMap ?? context.activeMap;
  if (map) {
    return (
      <MindMap
        map={map}
        selectedId={context.selected?.id ?? null}
        onSelect={(node) => context.openDocument(map.id, node.id)}
      />
    );
  }
  return (
    <div className="map-placeholder">
      <span>▦</span>
      <p>打开一个 .notes 知识库</p>
    </div>
  );
}

function ConsolePanel() {
  const context = useContext(PanelContext);
  if (!context) {
    return null;
  }
  return (
    <div className="console-panel">
      <div className="console-head">
        <span>控制台</span>
        <span className="console-status">就绪</span>
      </div>
      <div className="console-lines">
        {context.logs.map((line, index) => (
          <div key={index} className="console-line">
            <span className="console-prompt">›</span> {line}
          </div>
        ))}
      </div>
    </div>
  );
}

const components = {
  outline: OutlinePanel,
  document: DocumentPanel,
  map: MapPanel,
  console: ConsolePanel,
};

function WorkspaceTab(props: IDockviewPanelHeaderProps) {
  return (
    <div className="workspace-tab">
      <span className="workspace-tab-title">{props.api.title}</span>
      <button
        type="button"
        className="workspace-tab-close"
        title="关闭面板"
        onMouseDown={(event) => event.stopPropagation()}
        onPointerDown={(event) => event.stopPropagation()}
        onClick={(event) => {
          event.stopPropagation();
          props.api.close();
        }}
      >
        ×
      </button>
    </div>
  );
}

export default forwardRef<
  DockWorkspaceHandle,
  {
    workspace: WorkspaceView | null;
    activeMap: MapView | null;
    selected: NodeView | null;
    logs: string[];
    onActiveNode: (node: NodeView) => void;
    onPanelDirty: (panelId: string, dirty: boolean) => void;
    onSelectNode: (node: NodeView, newPanel: boolean) => void;
    onSwitchMap: (map: MapView) => void;
  }
>(function DockWorkspace(
  {
    workspace,
    activeMap,
    selected,
    logs,
    onActiveNode,
    onPanelDirty,
    onSelectNode,
    onSwitchMap,
  },
  ref,
) {
  const apiRef = useRef<DockviewApi | null>(null);
  const nextMapId = useRef(1);
  const pendingOpen = useRef<{
    mapId: string;
    nodeId: string;
  } | null>(null);
  const [activePanelId, setActivePanelId] = useState<string | null>(null);

  useEffect(() => {
    const api = apiRef.current;
    const panel = api?.getPanel("map");
    if (panel && !panel.api.getParameters<MapParams>().mapId) {
      panel.api.setTitle(activeMap?.title ?? "导图");
    }
  }, [activeMap?.title]);

  function resolveNode(params: DocParams | undefined): NodeView | null {
    if (!params?.mapId || !params.nodeId) {
      return null;
    }
    const map = workspace?.maps.find((item) => item.id === params.mapId);
    return map ? findNode(map.root, params.nodeId) : null;
  }

  function documentPanelId(mapId: string, nodeId: string): string {
    return `doc_${mapId}_${nodeId}`;
  }

  function openDocument(mapId: string, nodeId: string) {
    const api = apiRef.current;
    if (!api) {
      pendingOpen.current = { mapId, nodeId };
      return;
    }

    const panelId = documentPanelId(mapId, nodeId);
    const existing = api.getPanel(panelId);
    if (existing) {
      existing.api.setActive();
      setActivePanelId(existing.id);
      return;
    }

    const map = workspace?.maps.find((item) => item.id === mapId);
    const node = map ? findNode(map.root, nodeId) : null;
    const title = node?.title ?? "文档";
    const hasDocumentPanels = api.panels.some((panel) =>
      panel.id.startsWith("doc_"),
    );
    const reference = hasDocumentPanels
      ? api.activePanel?.id
      : "outline";

    const panel = api.addPanel({
      id: panelId,
      component: "document",
      title,
      params: { mapId, nodeId },
      ...(reference
        ? {
            position: {
              referencePanel: reference,
              direction: "right" as const,
            },
            initialWidth: 520,
          }
        : {}),
    });
    panel.api.setActive();
    setActivePanelId(panel.id);
  }

  function openMap(mapId: string, newPanel = true) {
    const api = apiRef.current;
    if (!api) {
      return;
    }
    const map = workspace?.maps.find((item) => item.id === mapId);
    const title = map?.title ?? "导图";
    const params: MapParams = { mapId };

    if (!newPanel) {
      const active = api.activePanel;
      if (active?.api.component === "map") {
        active.api.updateParameters(params);
        active.api.setTitle(title);
        active.api.setActive();
        return;
      }
    }

    const reference = api.activePanel?.id;
    const panel = api.addPanel({
      id: `map-${nextMapId.current++}`,
      component: "map",
      title,
      params,
      ...(reference
        ? {
            position: {
              referencePanel: reference,
              direction: "right" as const,
            },
            initialWidth: 420,
          }
        : {}),
    });
    panel.api.setActive();
  }

  useImperativeHandle(ref, () => ({ openDocument, openMap }));

  function buildDefaultLayout(api: DockviewApi) {
    api.addPanel({
      id: "outline",
      component: "outline",
      title: "大纲",
    });
    api.addPanel({
      id: "map",
      component: "map",
      title: activeMap?.title ?? "导图",
      position: { referencePanel: "outline", direction: "right" },
      initialWidth: 380,
      inactive: true,
    });

    try {
      api.addPanel({
        id: "console",
        component: "console",
        title: "控制台",
        position: { referencePanel: "map", direction: "within" },
        inactive: true,
      });
    } catch {
      // 导图面板不可用时，控制台作为独立面板追加。
      api.addPanel({
        id: "console",
        component: "console",
        title: "控制台",
      });
    }

    requestAnimationFrame(() => {
      api.getPanel("outline")?.group.api.setSize({ width: 260 });
      api.getPanel("map")?.group.api.setSize({ width: 380 });
    });
  }

  function onReady(event: DockviewReadyEvent) {
    apiRef.current = event.api;

    const saved = window.localStorage.getItem(DOCK_LAYOUT_KEY);
    if (saved) {
      try {
        event.api.fromJSON(JSON.parse(saved));
      } catch {
        window.localStorage.removeItem(DOCK_LAYOUT_KEY);
      }
    }

    if (event.api.panels.length === 0) {
      buildDefaultLayout(event.api);
    }

    let maxMapId = 0;
    for (const panel of event.api.panels) {
      if (panel.id.startsWith("map-")) {
        const value = Number(panel.id.slice(4));
        if (Number.isFinite(value)) {
          maxMapId = Math.max(maxMapId, value);
        }
      }
    }
    nextMapId.current = Math.max(1, maxMapId + 1);

    setActivePanelId(event.api.activePanel?.id ?? null);

    event.api.onDidLayoutChange(() => {
      window.localStorage.setItem(
        DOCK_LAYOUT_KEY,
        JSON.stringify(event.api.toJSON()),
      );
    });

    event.api.onDidActivePanelChange((event) => {
      const panel = event.panel;
      setActivePanelId(panel?.id ?? null);
      if (panel?.id.startsWith("doc_")) {
        const node = resolveNode(panel.api.getParameters<DocParams>());
        if (node) {
          onActiveNode(node);
        }
      }
    });

    const pending = pendingOpen.current;
    if (pending) {
      pendingOpen.current = null;
      openDocument(pending.mapId, pending.nodeId);
    }
  }

  const contextValue: PanelContextValue = {
    workspace,
    activeMap,
    activePanelId,
    selected,
    logs,
    openDocument,
    setPanelDirty: onPanelDirty,
    onSelectNode,
    onSwitchMap,
  };

  return (
    <PanelContext.Provider value={contextValue}>
      <DockviewReact
        className="dock-workspace"
        theme={themeAbyss}
        components={components}
        defaultTabComponent={WorkspaceTab}
        onReady={onReady}
        dndStrategy="html5"
        dndCompass
      />
    </PanelContext.Provider>
  );
});
