import {
  defaultKeymap,
  history,
  historyKeymap,
} from "@codemirror/commands";
import { markdown } from "@codemirror/lang-markdown";
import { markdownCodeLanguages } from "./markdownLanguages";
import { markdownCodeHighlighting } from "./codeHighlight";
import {
  bracketMatching,
  defaultHighlightStyle,
  indentOnInput,
  syntaxHighlighting,
} from "@codemirror/language";
import { EditorState } from "@codemirror/state";
import { EditorView, drawSelection, highlightActiveLine, keymap } from "@codemirror/view";
import { livePreview } from "./livePreview";
import {
  clearHeading,
  heading1,
  heading2,
  heading3,
  heading4,
  heading5,
  heading6,
  insertLink,
  toggleBold,
  toggleItalic,
} from "./formattingCommands";
import {
  markdownEnter,
  markdownShiftEnter,
  markdownShiftTab,
  markdownTab,
} from "./markdownCommands";

export function createMarkdownExtensions(onSave: () => void) {
  return [
    markdown({ codeLanguages: markdownCodeLanguages }),
    history(),
    drawSelection(),
    highlightActiveLine(),
    indentOnInput(),
    bracketMatching(),
    syntaxHighlighting(defaultHighlightStyle, { fallback: true }),
    markdownCodeHighlighting,
    livePreview(),
    EditorView.lineWrapping,
    EditorState.allowMultipleSelections.of(true),
    keymap.of([
      {
        key: "Mod-s",
        preventDefault: true,
        run: () => {
          onSave();
          return true;
        },
      },
      { key: "Enter", run: markdownEnter },
      { key: "Shift-Enter", run: markdownShiftEnter },
      { key: "Tab", run: markdownTab },
      { key: "Shift-Tab", run: markdownShiftTab },
      { key: "Mod-b", run: toggleBold },
      { key: "Mod-i", run: toggleItalic },
      { key: "Mod-k", run: insertLink },
      { key: "Mod-Alt-0", run: clearHeading },
      { key: "Mod-Alt-1", run: heading1 },
      { key: "Mod-Alt-2", run: heading2 },
      { key: "Mod-Alt-3", run: heading3 },
      { key: "Mod-Alt-4", run: heading4 },
      { key: "Mod-Alt-5", run: heading5 },
      { key: "Mod-Alt-6", run: heading6 },
      ...defaultKeymap,
      ...historyKeymap,
    ]),
  ];
}
